export const environment = {
  production: true,
  APIconfigURL: 'https://api.exchangeratesapi.io/latest'
};
